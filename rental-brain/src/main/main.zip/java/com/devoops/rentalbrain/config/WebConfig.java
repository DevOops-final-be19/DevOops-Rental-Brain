package com.devoops.rentalbrain.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class WebConfig {

}

