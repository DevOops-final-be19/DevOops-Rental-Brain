package com.devoops.rentalbrain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentalBrainApplication {

    public static void main(String[] args) {
        SpringApplication.run(RentalBrainApplication.class, args);
    }

}
