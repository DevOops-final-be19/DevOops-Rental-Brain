package com.devoops.rentalbrain.business.contract.query.dto;

import lombok.Data;

@Data
public class ContractItemSummaryDTO {
    private String itemName;
    private Integer quantity;
}
